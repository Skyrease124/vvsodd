import assert from 'node:assert/strict';
import { add } from './math.mjs';
assert.equal(add(2, 2), 4);
console.log('PASS: uploaded project imports and tests work');
