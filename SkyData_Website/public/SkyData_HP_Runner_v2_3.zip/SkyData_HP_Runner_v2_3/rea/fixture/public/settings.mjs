export const theme = 'dark';
